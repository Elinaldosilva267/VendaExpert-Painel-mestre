# VendaXpert - Painel Mestre

Plataforma de administração digital com IA, blockchain e gráficos.
import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from "recharts";

const data = [
  { name: "Jan", uv: 400 },
  { name: "Feb", uv: 700 },
  { name: "Mar", uv: 1000 },
  { name: "Apr", uv: 2000 },
  { name: "May", uv: 1500 }
];

function App() {
  return (
    <div style={{ padding: 24 }}>
      <h1>Painel Mestre - VendaXpert</h1>
      <p>Visualização gráfica de desempenho:</p>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Line type="monotone" dataKey="uv" stroke="#8884d8" activeDot={{ r: 8 }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export default App;
